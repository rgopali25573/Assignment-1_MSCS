import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Measure Conversion App',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),
      home: const MyHomePage(title: 'Measures Converter'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});
  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  final TextEditingController _controller = TextEditingController();
  String _selectedFromUnit = 'Meters';
  String _selectedToUnit = 'Kilometers';
  String _lastFromUnit = '';
  String _lastToUnit = '';
  double _convertedValue = 0.0;
  double input_value= 0.0;

  final List<String> _units = ['Meters', 'Kilometers', 'Feet', 'Miles'];

  void _convert() {
    double inputValue = double.tryParse(_controller.text) ?? 0;
    double conversionRate =
        _getConversionRate(_selectedFromUnit, _selectedToUnit);
    setState(() {
      _convertedValue = inputValue * conversionRate;
      input_value=inputValue;
      _lastFromUnit = _selectedFromUnit;
      _lastToUnit = _selectedToUnit;
    });
  }

  double _getConversionRate(String from, String to) {
    if (from == to) return 1.0;
    if (from == 'Meters' && to == 'Kilometers') return 0.001;
    if (from == 'Kilometers' && to == 'Meters') return 1000;
    if (from == 'Meters' && to == 'Feet') return 3.28084;
    if (from == 'Feet' && to == 'Meters') return 0.3048;
    if (from == 'Miles' && to == 'Kilometers') return 1.60934;
    if (from == 'Kilometers' && to == 'Miles') return 0.621371;
    return 1.0; // default conversion for unsupported pairs
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Center(child: Text(widget.title)),
        backgroundColor: Colors.blue,
        foregroundColor: Colors.white,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            const Text("Value"),
            TextField(
              controller: _controller,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                hintText: 'Enter value to convert',
              ),
            ),
            const SizedBox(height: 16.0),
            const Text("From"),
            DropdownButton<String>(
              value: _selectedFromUnit,
              onChanged: (newValue) {
                setState(() {
                  _selectedFromUnit = newValue!;
                });
              },
              items: _units.map<DropdownMenuItem<String>>((String value) {
                return DropdownMenuItem<String>(
                  value: value,
                  child: Text(value),
                );
              }).toList(),
            ),
            const SizedBox(height: 16.0),
            const Text("To"),
            DropdownButton<String>(
              value: _selectedToUnit,
              onChanged: (newValue) {
                setState(() {
                  _selectedToUnit = newValue!;
                });
              },
              items: _units.map<DropdownMenuItem<String>>((String value) {
                return DropdownMenuItem<String>(
                  value: value,
                  child: Text(value),
                );
              }).toList(),
            ),
            const SizedBox(height: 20.0),
            ElevatedButton(
              onPressed: _convert,
              child: const Text("Convert"),
            ),
            const SizedBox(height: 20.0),
            Text(
              "$input_value $_lastFromUnit are $_convertedValue $_lastToUnit",
              style:
                  const TextStyle(fontSize: 18.0, fontWeight: FontWeight.bold),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}
